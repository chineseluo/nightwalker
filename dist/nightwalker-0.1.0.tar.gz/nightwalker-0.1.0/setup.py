# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['nightwalker', 'nightwalker.builtin']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML==5.3.1',
 'loguru==0.5.3',
 'mkdocs-material>=6.0.2,<7.0.0',
 'mkdocs>=1.1.2,<2.0.0',
 'pytest-html>=2.1.1,<3.0.0',
 'pytest>=5.2,<6.0',
 'requests==2.24.0']

extras_require = \
{'allure': ['allure-pytest>=2.8.16,<3.0.0']}

entry_points = \
{'console_scripts': ['nightwalker = nightwalker.cli:main',
                     'nw = nightwalker.cli:main']}

setup_kwargs = {
    'name': 'nightwalker',
    'version': '0.1.0',
    'description': 'We need more free software interface testing.',
    'long_description': '# nightwalker\n夜行者社区接口自动化项目，提供的是更多地灵活性和可配置性\n',
    'author': 'chineseluo',
    'author_email': '848257135@qq.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/httprunner/httprunner',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
